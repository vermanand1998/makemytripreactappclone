import React from "react";
import "./searchbutton.css";

const Searchbutton = () => {
  return (
    <>
      <button className="searchBtn">SEARCH</button>
    </>
  );
};

export default Searchbutton;
