import React from "react";
import "./otherwidget.css";
const OtherWidget = () => {
  return (
    <>
      <div className="otherwidget-maindiv">
        <p>Upcoming...</p>
      </div>
    </>
  );
};
export default OtherWidget;
